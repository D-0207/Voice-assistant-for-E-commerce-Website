import { useState, useCallback } from 'react';

const useSearchitem = () => {
    const [items, setitems] = useState([]);
    const [isFetchingitems, setIsFetchingitems] = useState(false);

    const fetchitem = useCallback(({detail :{items}}) => {
        setIsFetchingitems(true);
        fetch(`${items}`)
        .then(res => res.json())
        .then(res => {
            setitems(res.docs.map(items => {
                return {
                    name: items.name,
                    category: items.category,
                    priceCents: items.price,
                    logo: items.logo
                    
                }
            }))
            setIsFetchingitems(false);
        });
    })

    return {
        items,
        fetchitem,
        isFetchingitems,
    };
};

export {
    useSearchitem,
}